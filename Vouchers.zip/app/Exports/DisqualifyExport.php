<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class DisqualifyExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return DB::table('winners')->leftJoin('shops', 'winners.user_id', '=', 'shops.user_id')->select('winners.*', 'shops.sname', 'shops.location')->where(['disqualified'=> 1])->get();
    }

    public function headings(): array

    {

        return [

            'id',

            'Name',

            'Email Address',

            'Phone Number',

            'Code',

            'Product',

            'Serial Number',

            'TOS',

            'Created At',

            'Updated At',

            'Receipt Number',

            'Amount',

            'Points',

            'Shop ID',
            
            'Shop',

            'Location',

        ];

    }
}

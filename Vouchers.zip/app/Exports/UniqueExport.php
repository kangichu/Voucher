<?php

namespace App\Exports;

use App\Register;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class UniqueExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return DB::table('vouchers')->select('amount', 'code')->where('user_id', 1)->take(1)->get();
    }

    public function headings(): array

    {

        return [


            'voucher_amount',

            'code',

        ];

    }
}

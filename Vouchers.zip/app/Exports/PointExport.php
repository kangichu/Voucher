<?php

namespace App\Exports;

use App\Point;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class PointExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return DB::table('points')->join('shops', 'points.user_id', '=', 'shops.user_id')->select('points.*', 'shops.sname', 'shops.location')->get();
    }

    public function headings(): array

    {

        return [

            'id',

            'Name',

            'Email Address',

            'Phone Number',

            'Code',

            'Product',

            'Serial Number',

            'Amount',

            'Receipt Number',

            '',

            'Created At',

            'Updated At',

            'Shop',

            'location',
            
            

        ];

    }
}

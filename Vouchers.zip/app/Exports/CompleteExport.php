<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use App\Register;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CompleteExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return DB::table('sample')->get();
    }

    public function headings(): array

    {

        return [
            
            'first_name',

            'phone_number',

            'region',

            'voucher_amount',


        ];

    }
}

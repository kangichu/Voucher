<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Voucher extends Model
{
	protected $table = 'vouchers';

    protected $fillable =  [
        'user_id', 'amount', 'code', 'quantity',
    ];

    

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}

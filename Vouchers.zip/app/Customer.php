<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class Customer extends Model
{
    protected $table = 'contacts';

    protected $fillable =  ["name", "mobile", "region", "voucher_amount", "unique_intentifier", "user_id"];

    public static function getCustomers()
    {
    	$record = DB::table('contacts')->select("id", "name", "mobile", "region", "voucher_amount", "unique_intentifier", "user_id")->orderBy("id", "asc");

    	return $records;
    }

}
<?php

namespace App\Imports;

use App\Customer;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\Importable;
use Illuminate\Validation\Rule;


class CustomerImport implements ToModel, WithHeadingRow
{

    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Customer([
            "name" => $row["first_name"],
            "mobile"  => $row["phone_number"],
            "region" => $row["region"],
            "voucher_amount" => $row["voucher_amount"],
            "unique_intentifier" => $row["unique_intentifier"],
            "user_id" => auth()->user()->id,
        ]);
    }

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Register;
use Carbon\Carbon;
use App\Exports\CompleteExport;
use App\Exports\PointExport;
use App\Exports\UniqueExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Voucher;
use App\User;
use Auth;


class EntriesController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       /*$CodeCount= DB::connection('mysql2')->table('codes')->count();*/
       $entriesCount= DB::table('contacts')->count();
       $uniqueEntriesCount= DB::table('contacts')->distinct('mobile')->count();
       $completeEntries= DB::table('points')->count();
       $voucherCount = Voucher::get()->count();
       $userCount = User::get()->count();
       $voucherAvailCount = Voucher::where('used', null)->get()->count();
       $totalbulk= DB::connection('mysql2')->table('bulkSMSBalance')->select('balance')->where('groupName', 'test')->first();

       return view('entries.all')->with(array('uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'userCount'=>$userCount, 'voucherCount'=>$voucherCount, 'totalbulk' => $totalbulk, 'voucherAvailCount' => $voucherAvailCount));
    }

    public function valid()
    {

        $entriesCount= DB::table('contacts')->count();
        $uniqueEntriesCount= DB::table('contacts')->distinct('mobile')->count();
        $completeEntries= DB::table('points')->count();
        $voucherCount = Voucher::get()->count();
        $voucherAvailCount = Voucher::where('used', null)->get()->count();
        $userCount = User::get()->count();
        $totalbulk= DB::connection('mysql2')->table('bulkSMSBalance')->select('balance')->where('groupName', 'test')->first();

       return view('entries.valid')->with(array('uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'userCount'=>$userCount, 'voucherCount'=>$voucherCount, 'totalbulk' => $totalbulk, 'voucherAvailCount' => $voucherAvailCount));
    }

    public function invalid()
    {
        $user_id = auth()->user()->id;
        $templates = DB::table('sms_templates')->where('user_id', $user_id)->get();
        $entriesCount= DB::table('contacts')->count();
        $uniqueEntriesCount= DB::table('contacts')->distinct('mobile')->count();
        $completeEntries= DB::table('points')->count();
        $voucherAvailCount = Voucher::where('used', null)->get()->count();
        $voucherCount = Voucher::get()->count();
        $userCount = User::get()->count();
        $totalbulk= DB::connection('mysql2')->table('bulkSMSBalance')->select('balance')->where('groupName', 'test')->first();

       return view('entries.invalid')->with(array('uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'userCount'=>$userCount, 'voucherCount'=>$voucherCount, 'templates'=>$templates, 'totalbulk' => $totalbulk, 'voucherAvailCount' => $voucherAvailCount));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }


    public function template(Request $request)
    {
        $this->validate($request,
            [
                'name' => 'required|max:50',
                'message' => 'required|max:160',
            ], 
            [
                'name.required' => 'This is a required field.',
                'name.max' => 'The character limit is set at 50.',
                'message.required' => 'This is a required field.',
                'message.max' => 'The character limit is set at 140',
            ]
        );

        $name = $request->input('name');
        $message = $request->input('message');
        $user_id = auth()->user()->id;
        $now = Carbon::now();


        DB::insert('insert into sms_templates (user_id, name, message, created_at, updated_at) values (?, ?, ?, ?, ?)', [$user_id, $name, $message, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);
        return redirect()->back()->with("success","Template created successfully.");
    }

    public function template_update(Request $request)
    {
        $this->validate($request,
            [
                'name' => 'required|max:50',
                'message' => 'required|max:140',
            ], 
            [
                'name.required' => 'This is a required field.',
                'name.max' => 'The character limit is set at 50.',
                'message.required' => 'This is a required field.',
                'message.max' => 'The character limit is set at 140',
            ]
        );

        $name = $request->input('name');
        $id = $request->input('template_id');
        $message = $request->input('message');
        $user_id = auth()->user()->id;
        $now = Carbon::now();


        DB::table('sms_templates')
        ->where([
            ['user_id', $user_id], 
            ['id',$id],
        ])
        ->update([
            'name' => $name,
            'message'=> $message,
            'updated_at' => $now->format('Y-m-d H:i:s'),
        ]);


        return redirect()->back()->with("success","Template Updated successfully.");
    }


    public function destroy($id)
    {
        $template = DB::table('sms_templates')->where('id', $id)->first();

        if(auth()->user()->id !== $template->user_id){
            return back();
        }

         if(Auth::user()->hasRole('administrator') || Auth::user()->hasRole('superadministrator')){ 

            DB::table('sms_templates')->where('id', $id)->delete();  

            return redirect()->back()->with("success","Template Deleted successfully.");
        } else { 
            return back();
        }
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $this->validate($request,
            [
                'name' => ['string', 'max:255'],
                'email' => ['string', 'email', 'max:255'],
                'mobile' => ['numeric'],
                'code' => ['string' ,'max:255'],
                'product' => ['string', 'max:255'],
                'serial' => ['string',  'max:255'],
            ], 
            [
                'name.max' => 'The character limit is set at 140.',
            ]
        );

        $user = Register::find($id);  
        $user->name = $request->input('name');
        $user->email =  $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->code = $request->input('code');
        $user->product = $request->input('product');
        $user->serial = $request->input('serial');
        $user->save();  // Update the data

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function tos()
    {
        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );
                     
        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        return view('tos.tos')->with(array('usersCount'=>$usersCount,  'dates'=>$dates));
    }

    public function privacy()
    {
        return view('tos.privacy');
    }

    public function completExport() 
    {
        return Excel::download(new CompleteExport, 'Template.xlsx');
    }

    public function pointExport() 
    {
        return Excel::download(new PointExport, 'All-Entry-Points.xlsx');
    }

    public function voucherExport() 
    {
        return Excel::download(new UniqueExport, 'voucher-sample.xlsx');
    }

    public function csvcompletExport() 
    {
        return Excel::download(new CompleteExport, 'All-Entries.csv');
    }

    public function csvpointExport() 
    {
        return Excel::download(new PointExport, 'All-Entry-Points.csv');
    }

    public function csvuniquExport() 
    {
        return Excel::download(new UniqueExport, 'Unique-Customers.csv');
    }

}

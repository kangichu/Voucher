<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;

class SMSController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        $user_id = auth()->user()->id;
        $smses = DB::table('messages_outgoing')->where('user_id', $user_id)->get();
        $resend = DB::table('messages_outgoing')->where([['user_id', $user_id], ['status', 2]])->count();

        return view('SMS.history')->with(array('smses'=>$smses, 'resend' => $resend)); 
    }

    public function resend()
    {
        $user_id = auth()->user()->id;
        $user = DB::table('users')->where('id', $user_id)->first();
        $clientMessage = DB::table('messages_outgoing')->where([['user_id', $user_id], ['status', 2]])->count();

        for($i = 0; $i<$clientMessage; $i++)
        {
            $sendMessage = DB::table('messages_outgoing')->where([['user_id', $user_id], ['status', 2]])->take(1)->first();
            

            $headers = [
                'Cookie: ci_session=ttdhpf95lap45hqt3h255af90npbb3ql'

            ];

            try
            {
                $encodMessage = rawurlencode($sendMessage->message);
                $url = 'https://gcd.ims.co.ke/expresssms/Api/send_bulk_api?action=send-sms&api_key=Snh2SGFQT0dIZmFtRGU9ZXBlcEQ=&to='.$sendMessage->mobile.'&from='.$user->sender_id.'&sms='.$encodMessage.'&response=json&unicode=0&bulkbalanceuser=voucher';
    
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_ENCODING, "");
                curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                curl_setopt($ch, CURLOPT_TIMEOUT, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true,);
                curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    
                $response = curl_exec($ch);
                $res = json_decode($response);
                
                if($res->code == "ok")
                {
                    DB::table('messages_outgoing')
                    ->where([
                        ['user_id', $user_id], 
                        ['id', $sendMessage->id],
                    ])
                    ->update([
                        'status' => 4,
                    ]);
                }
                curl_close($ch);
            }   catch (\Exception $e) {

                return redirect()->back()->with("error",$e);
            }
        }

        return redirect()->back()->with("success","Your voucher codes are being sent to your contacts.");

    }

       
}

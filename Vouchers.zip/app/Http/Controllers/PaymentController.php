<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;


class PaymentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
   public function index()
    {

        $user_id = auth()->user()->id;
        $history = DB::table('amount_paid')->where('user_id', $user_id)->get();
        /*$allhistory = DB::table('amount_paid')->get();*/

        $allhistory = DB::table('amount_paid')
               ->join('users', 'amount_paid.user_id', '=', 'users.id')
               ->get();


        return view('payment.history')->with(array('history'=>$history, 'allhistory' => $allhistory)); 
    }
}

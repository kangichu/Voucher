<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Permission;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Register;
use Carbon\Carbon;
use Auth;
use App\Product;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('role:user|superadministrator');
    }

    public function index()
    {
        $senderID= DB::connection('mysql2')->table('bulksms_clients')->get();
        $entriesCount= Register::get()->count();
        $uniqueEntriesCount= Register::distinct('mobile')->count();
        $completeEntries= DB::table('points')->count();

        $shopsCount = DB::table('registers')->join('shops', 'registers.user_id', '=', 'shops.user_id')->select('registers.*', 'shops.sname', 'shops.location')->distinct('shops.sname')->count();

        $entries= DB::table('registers')->orderBy('created_at', 'desc')->get();

        $productList = DB::table('products')->get();

        $user_id =  auth()->user()->id;
        $allshopsCount = DB::table('shops')->count();
        $user= DB::table('shops')->where('user_id', '=', $user_id)->first();

        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        if ((Auth::user()->password_change_at == null)) {
             return redirect(route('passForm'));
        }
        else{
            return view('search.search')->with(array('senderID'=>$senderID, 'completeEntries'=> $completeEntries, 'uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'entries'=>$entries, 'productList'=>$productList, 'user' => $user, 'usersCount'=>$usersCount, 'shopsCount'=>$shopsCount, 'allshopsCount'=>$allshopsCount, 'dates'=>$dates));
        }
       
    }

    

    public function users()
    {
        $supers = User::whereRoleIs('superadministrator')->get();
        /*->orWhereRoleIs('administrator')*/
        $senderID= DB::connection('mysql2')->table('bulksms_clients')->get();
      
        $admins = User::whereRoleIs('administrator')->get();

        /*$users= User::whereRoleIs('user')->get();*/

        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        $voucheramount = DB::table('default_vamount')->get();

        return view('users.all')->with(array('senderID'=>$senderID/*, 'users'=>$users*/, 'supers'=>$supers, 'admins'=>$admins, 'usersCount'=>$usersCount, 'dates'=>$dates, 'voucheramount'=>$voucheramount));

    }

    public function userscreate()
    {
        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );
        $senderID= DB::connection('mysql2')->table('bulksms_clients')->get();

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $voucheramount = DB::table('default_vamount')->get();
                     
        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        return view('users.create')->with(array('usersCount'=>$usersCount, 'dates'=>$dates,'senderID'=>$senderID, 'voucheramount'=>$voucheramount));
    }

    public function store(Request $request)
    {
        $this->validate($request,
            [
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'mobile' => ['required', 'numeric', 'unique:users'],
                'amount_paid' => ['required', 'numeric'],
                'voucher_value' => ['required', 'numeric'],
                'sender_id' => 'required',
                'compaign_name' => ['required', 'string', 'max:255'],
                'Supermarket' => ['required', 'string', 'max:255'],
                'contacts' => ['required', 'numeric', 'max:255'],
            ], 
            [
                'name.required' => 'This is a required field.',
                'compaign_name.required' => 'This is a required field.',
                'Supermarket.required' => 'This is a required field.',
                'contacts.required' => 'This is a required field.',
                'name.max' => 'The character limit is set at 140.',
                'email.required' => 'We need to know your e-mail address!',
                'amount_paid.required' => 'This is a required field.',
                'voucher_value.required' => 'This is a required field.',
                'sender_id.required' => 'This is a required field.',
            ]
        );

        $password = rand(1000,9999);

        function generate_uuid() {
            return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
                mt_rand( 0, 0xffff ),
                mt_rand( 0, 0x0C2f ) | 0x4000,
                mt_rand( 0, 0x3fff ) | 0x8000,
                mt_rand( 0, 0x2Aff ), mt_rand( 0, 0xffD3 ), mt_rand( 0, 0xff4B )
            );
        }
        

        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'compaign_name' => $request->input('compaign_name'),
            'Supermarket' => $request->input('Supermarket'),
            'contacts' => $request->input('contacts'),
            'mobile' => $request->input('mobile'),
            'amount_paid' => $request->input('amount_paid'),
            'voucher_value' => $request->input('voucher_value'),
            'sender_id' => $request->input('sender_id'),
            'password' => Hash::make($password),
            'password_change_at' => 1,
        ]);

        $user->attachRole('administrator');

        $amount_paid = $request->input('amount_paid');
        $voucher_value = $request->input('voucher_value');
        $quantity =  floor($amount_paid/$voucher_value);
        $now = Carbon::now();
        $user_id = $user->id;


        for($i=1; $i<=$quantity; $i++){

            $code=generate_uuid();

            DB::insert('insert into vouchers (user_id, quantity, amount, code, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $quantity, $voucher_value, $code, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);
        }

        DB::insert('insert into amount_paid (user_id, quantity, amount, voucher_value, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $quantity, $amount_paid, $voucher_value, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);

        $details = [
                'title' => 'Hi '.$request->input('name'),
                'body' => 'Welcome to the Voucher System, your credentials include mobile: '.$request->input('mobile').' and password: '.$password
            ];

        //Mail::to($request->input('email'))->send(new \App\Mail\canonMail($details));

        /*if($user){

            $headers = [
                "Accept: /",
                "Accept-Encoding: gzip, deflate",
                "Cache-Control: no-cache",
                "Connection: keep-alive",
                "Content-Length: 0",
                "Host: 3.229.54.57:8080",
                "Postman-Token: 93db88fd-7432-4cf8-a96f-37dbba8f31b5,434f449e-69da-4341-a0ae-9c261a167ae4",
                "User-Agent: PostmanRuntime/7.19.0",
                "cache-control: no-cache",
                "id: ".$request->input('mobile'),
                "message: Welcome to the Twendeni Porini Na Canon Promotion, your credentials include mobile: ".$request->input('mobile')." and password: ".$password." at http://canon.ims.co.ke/",
                "network: 9",
                "originator: 700801",
                "serviceid: 6013872000123962"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_PORT, "8080");
            curl_setopt($ch, CURLOPT_URL, "http://3.229.54.57:8080/guinnessutcSMS/sendBulkSMS");
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 8);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

            // execute!
            $response = curl_exec($ch);

            // close the connection, release resources used
            curl_close($ch);
        }*/


        return redirect('/users');
    }


    public function destroy($id)
    {
        $user = User::find($id);

        if(Auth::user()->hasRole('superadministrator')){ 
            $user->delete();  
            return back();
        } else { 
            return back();
        }
       
    }

    public function preset(Request $request)
    {
        $id = $request->input('user_id');
        $password = rand(1000,9999);
        $user = User::find($id);

        if(Auth::user()->hasRole('superadministrator')){

            $user->password = Hash::make($password);
            $user->password_change_at = 1;
            $user->save();


            $details = [
                'title' => 'Hi '.$user->name,
                'body' => 'Welcome to the Voucher System, your credentials include mobile: '.$user->mobile.' and new password: '.$password.' at http://canon.ims.co.ke/'
            ];

             Mail::to($user->email)->send(new \App\Mail\canonMail($details));

            /*if($user){

                $headers = [
                    "Accept: /*",
                    "Accept-Encoding: gzip, deflate",
                    "Cache-Control: no-cache",
                    "Connection: keep-alive",
                    "Content-Length: 0",
                    "Host: 3.229.54.57:8080",
                    "Postman-Token: 93db88fd-7432-4cf8-a96f-37dbba8f31b5,434f449e-69da-4341-a0ae-9c261a167ae4",
                    "User-Agent: PostmanRuntime/7.19.0",
                    "cache-control: no-cache",
                    "id: ".$user->mobile,
                    "message: Welcome to the Twendeni Porini Na Canon Promotion, your credentials include mobile: ".$user->mobile." and new password: ".$password." at http://canon.ims.co.ke/",
                    "network: 9",
                    "originator: 700801",
                    "serviceid: 6013872000123962"
                ];

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_PORT, "8080");
                curl_setopt($ch, CURLOPT_URL, "http://3.229.54.57:8080/guinnessutcSMS/sendBulkSMS");
                curl_setopt($ch, CURLOPT_ENCODING, "");
                curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                curl_setopt($ch, CURLOPT_TIMEOUT, 8);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

                $response = curl_exec($ch);

                curl_close($ch);
            }*/

            return redirect('/users');
        } else { 
            return back();
        }
       
    }


    public function update(Request $request, $id)
    {

        $this->validate($request,
            [
                'amount_paid' => 'numeric',
                'voucher_value' => 'numeric',
                'sender_id' => 'string',
            ]
        );

        $user = User::find($id);  
        $user->amount_paid = $request->input('amount_paid');
        $user->current_voucher_value = $request->input('voucher_value');
        $user->sender_id = $request->input('sender_id');
        $user->save();  // Update the data

        function generate_uuid() {
            return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
                mt_rand( 0, 0xffff ),
                mt_rand( 0, 0x0C2f ) | 0x4000,
                mt_rand( 0, 0x3fff ) | 0x8000,
                mt_rand( 0, 0x2Aff ), mt_rand( 0, 0xffD3 ), mt_rand( 0, 0xff4B )
            );
        }

        $amount_paid = $request->input('amount_paid');
        $voucher_value = $request->input('voucher_value');
        $quantity =  floor($amount_paid/$voucher_value);
        $now = Carbon::now();
        $user_id = $user->id;


        for($i=1; $i<=$quantity; $i++){

            $code=generate_uuid();

            DB::insert('insert into vouchers (user_id, quantity, amount, code, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $quantity, $voucher_value, $code, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);
        }

        DB::insert('insert into amount_paid (user_id, quantity, amount, voucher_value, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $quantity, $amount_paid, $voucher_value, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);


        return redirect('/users');
        
    }


    public function edit(Request $request, $id)
    {

        $this->validate($request,
            [
                'name' => ['string', 'max:255'],
                'email' => ['string', 'email', 'max:255'],
                'mobile' => ['numeric'],
                'compaign_name' => [ 'string', 'max:255'],
                'Supermarket' => [ 'string', 'max:255'],
                'contacts' => ['numeric', 'max:255'],
            ]
        );

        $user = User::find($id);  
        $user->name = $request->input('name');
        $user->email =  $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->compaign_name = $request->input('compaign_name');
        $user->Supermarket = $request->input('Supermarket');
        $user->contacts = $request->input('contacts');
        $user->save();  // Update the data

        return redirect('/users');
        
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Register;
use App\Product;
use App\Point;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;


class SearchController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        /*$CodeCount= DB::connection('mysql2')->table('codes')->count();*/
        $entriesCount= DB::connection('mysql2')->table('messages_incoming')->count();
        $uniqueEntriesCount= DB::connection('mysql2')->table('messages_incoming')->distinct('originator')->count();
        $completeEntries= Register::get()->count();

         $shopsCount = DB::table('registers')->join('shops', 'registers.user_id', '=', 'shops.user_id')->select('registers.*', 'shops.sname', 'shops.location')->distinct('shops.sname')->count();
        $allshopsCount = DB::table('shops')->count();
        
        $productList = DB::table('products')->get();
        $user_id =  auth()->user()->id;
        $user= DB::table('shops')->where('user_id', '=', $user_id)->first();

        $entries= DB::connection('mysql2')->table('messages_incoming')->where('status', 0)->orderBy('timereceived', 'desc')->get();

        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        return view('search.search')->with(array('entries'=> $entries, /*'CodeCount'=>$CodeCount,*/ 'completeEntries'=> $completeEntries, 'uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'productList'=>$productList, 'user' => $user, 'usersCount'=>$usersCount, 'shopsCount'=>$shopsCount, 'allshopsCount'=>$allshopsCount, 'dates'=>$dates));


    }

    public function store(Request $request)
    {

        try {
            $this->validate($request,
                [
                    'name' => ['required','string', 'max:255'],
                    'email' => ['required','string', 'email', 'max:255'],
                    'mobile' => ['required','numeric'],
                    'code' => ['string' ,'max:255'],
                    'receipt' => ['string' ,'max:255'],
                    'product' => ['string', 'max:255'],
                    'serial' => ['required','string',  'max:255'],
                    'tos' => ['required','numeric']
                ], 
                [
                    'name.max' => 'The character limit is set at 140.',
                    'name.required' => 'This is a required field.',
                    'email.required' => 'This is a required field',
                    'code.required' => 'This is a required field',
                    'receipt.required' => 'This is a required field',
                    'product.required' => 'This is a required field',
                    'serial.required' => 'This is a required field',
                    'tos.required' => 'This is a required field',
                ]
            );

            $code = $request->input('code');
            $product = $request->input('product');

            $validateCode = DB::connection('mysql2')->table('codes')->where([['code', '=', $code], ['used_status', '=', 1]])->count();


            if($validateCode != 0 )
            {
                $product_name= $request->input('product');

                $points = DB::table('products')->where('product_name', $product_name)->first();

                $user = new Register;  
                $user->name = $request->input('name');
                $user->email =  $request->input('email');
                $user->mobile = $request->input('mobile');
                $user->code = $request->input('code');
                $user->product = $request->input('product');
                $user->receipt = $request->input('receipt');
                $user->points = $points->points;
                $user->serial = $request->input('serial');
                $user->tos = $request->input('tos');
                $user->user_id = auth()->user()->id;
                $user->save();  // Update the data

                DB::connection('mysql2')->table('codes')->where('code', $code)->update(['used_status' => 4, 'product' => $product]);

                $array = array();

                $user_name = $request->input('name');
                $user_email =  $request->input('email');
                $user_mobile = $request->input('mobile');
                $user_code = $request->input('code');
                $user_product = $request->input('product');
                $receipt = $request->input('receipt');
                $user_points = 1;
                $user_serial = $request->input('serial');
                $user_user_id = auth()->user()->id;
                $now = Carbon::now();
               

                for ($i = 0; $i < $points->points; $i++) {
                    $array[] = array(
                        'name' => $user_name,
                        'email' => $user_email,
                        'mobile' => $user_mobile,
                        'code' => $user_code,
                        'product' => $user_product,
                        'receipt' => $receipt,
                        'serial' => $user_serial,
                        'user_id' => $user_user_id,
                        'created_at' => $now->format('Y-m-d H:i:s'),
                        'updated_at' => $now->format('Y-m-d H:i:s')
                    );

                }

                DB::table('points')->insert($array);
                $entriesCount= DB::table('points')->where('mobile', $user_mobile)->count();

                $details = [
                    'title' => 'Hi '.$user_name,
                    'body' => 'Thank you for participating in the Twendeni Porini na Canon Promotion. Also avail Cash Back offer on selected Canon products. Visit https://en.canon-cna.com/promotions/cashback/kenya for more details. Terms & Conditions Apply! Helpline 0768 116 826. SMS STOP to opt out of this promotion.'
                ];

                Mail::to($user_email)->send(new \App\Mail\canonMail($details));


                /*if($user){

                    $headers = [
                        "Accept: /*",
                        "Accept-Encoding: gzip, deflate",
                        "Cache-Control: no-cache",
                        "Connection: keep-alive",
                        "Content-Length: 0",
                        "Host: 3.229.54.57:8080",
                        "Postman-Token: 93db88fd-7432-4cf8-a96f-37dbba8f31b5,434f449e-69da-4341-a0ae-9c261a167ae4",
                        "User-Agent: PostmanRuntime/7.19.0",
                        "cache-control: no-cache",
                        "id: ".$request->input('mobile'),
                        "message: Thank you for participating in the Twendeni Porini na Canon Promotion. Also avail Cash Back offer on selected Canon products. Visit https://en.canon-cna.com/promotions/cashback/kenya for more details. Terms & Conditions Apply! Helpline 0768 116 826. SMS STOP to opt out of this promotion.
                        ",
                        "network: 9",
                        "originator: 700801",
                        "serviceid: 6013872000123962"
                    ];

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_PORT, "8080");
                    curl_setopt($ch, CURLOPT_URL, "http://3.229.54.57:8080/guinnessutcSMS/sendBulkSMS");
                    curl_setopt($ch, CURLOPT_ENCODING, "");
                    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

                    // execute!
                    $response = curl_exec($ch);

                    // close the connection, release resources used
                    curl_close($ch);
                }*/

                $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

                $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                         ->groupBy( 'date' )
                         ->orderBy( 'date' )
                         ->get( [
                             DB::raw( 'DATE( created_at ) as date' ),
                             DB::raw( 'COUNT( * ) as "count"' )
                         ] )
                         ->pluck( 'count', 'date' );

                $usersCount = DB::table('shops')
                   ->join('registers', 'shops.user_id', '=', 'registers.user_id')
                   ->selectRaw('shops.*, count(registers.id) as userCount')
                   ->groupBy('shops.id')
                   ->get();

                return view('search.customer')->with(array('usersCount'=> $usersCount, 'dates'=>$dates));

            } else {
                return redirect()->back()->with("error","Enter a Valid Code Number."); 
            }

           

        } catch (Throwable $e) {
            report($e);

             return redirect()->back()->with("error","Something went wrong, Please try again.");
        }
        
        
    }

    /*public function show($id)
    {
        $entrie = DB::connection('mysql2')->table('messages_incoming')->where('id', $id)->first();
        $productList = DB::table('products')->get();
        return view('search.customer')->with(array('entrie'=> $entrie, 'productList'=>$productList));
    }*/

}

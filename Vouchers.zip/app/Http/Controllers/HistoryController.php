<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HistoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        $user_id = auth()->user()->id;
        $history = DB::table('contacts')->where([['user_id', $user_id],['confirmation', '!=', null]])->get();
        $yes = DB::table('contacts')->where([['user_id', $user_id],['confirmation', '=', 'Confirmed']])->count();
        $no = DB::table('contacts')->where([['user_id', $user_id],['confirmation', '=', 'Unavailable Vouchers']])->count();
        $distinct = DB::table('contacts')
              ->select('voucher_amount', DB::raw('count(`voucher_amount`) as occurences'))
              ->where([['user_id', $user_id],['confirmation', '=', 'Unavailable Vouchers']])
              ->groupBy('voucher_amount')
              ->having('occurences', '>', 0)
              ->get();

         $voucheravailable = DB::table('vouchers')
              ->select('amount', DB::raw('count(`amount`) as occurences'))
              ->where([['user_id', $user_id],['used', '=', null]])
              ->groupBy('amount')
              ->having('occurences', '>', 0)
              ->get();

        $resend = DB::table('contacts')->where([['user_id', $user_id],['confirmation', '=', 'Unavailable Vouchers']])->count();
        $sender_id = DB::table('users')->where('id', $user_id)->first();
        $templates = DB::table('sms_templates')->where('user_id', $user_id)->get();
        $clientvoucheramount = DB::table('contacts')->where('user_id', $user_id)->distinct()->get(['voucher_amount']);

        return view('pending.pending')->with(array('history'=>$history, 'yes'=>$yes, 'no'=>$no, 'resend'=>$resend, 'sender_id' =>$sender_id, 'templates' => $templates, 'clientvoucheramount'=>$clientvoucheramount, 'distinct'=>$distinct, 'voucheravailable'=>$voucheravailable)); 
    }

    public function bulk(Request $request)
    {
        $this->validate($request,
            [
                'message' => 'max:160'
            ], 
            [
                'message.max' => 'The character limit is set at 140'
            ]
        );

        $sender_id = $request->input('sender_id');
        $message = $request->input('message');
        $user_id = auth()->user()->id;
        $now = Carbon::now();


        //Take Data From Contacs table to Contact List table
        $entryCount = DB::table('contacts')->where([['user_id', $user_id],['confirmation','=', 'Unavailable Vouchers']])->count();

        if($entryCount === 0) 
        {
            return redirect()->back()->with("error","All customers have been issued their vouchers ");
        } 


        function getNum($vouchers, $targetVoucherAmount){
            $remainders = [];
            $voucherAllocation = 0;
            rsort($vouchers, SORT_NUMERIC);
            $vouchers = array_values($vouchers);
            foreach ($vouchers as $key => $amount) {
                $remainder = $amount % $targetVoucherAmount;
                if (($remainder == 0) && ($amount == $targetVoucherAmount)) {
                    // We found an exact match exit
                    $voucherAllocation = $amount;
                    break;
                }
                //echo "Not broken. \n";
                $remainders[$key] = $remainder;
            }
            if (!empty($voucherAllocation)) {
                return $voucherAllocation;
                exit;
            }

            $voucherUnitsToCombine = [];
            reset($remainders);
            reset($vouchers);
            // try find a combination that adds up to the target amount
            foreach ($remainders as $key => $value) {
                if ($value != $vouchers[$key]) {
                    /*echo "Remainder Key=$key; Remainder Value=$value; Voucher Value=$vouchers[$key] \n";*/
                    continue;
                }
                $amount = $vouchers[$key];
            //    echo __LINE__;
            //    echo PHP_EOL;
                // we have a number that was not greater than the target voucher amount
                $intermediateValue = array_sum($voucherUnitsToCombine) + $amount;

                if ($intermediateValue == $targetVoucherAmount) {
                    $voucherUnitsToCombine[] = $amount;
                    break;
                }
                if ($intermediateValue > $targetVoucherAmount) {
                    continue;
                }
                if ($intermediateValue < $targetVoucherAmount) {
                    $voucherUnitsToCombine[] = $amount;
                    continue;
                }

                return $intermediateValue;
            }

            if($intermediateValue == $targetVoucherAmount)
            {
                $result = json_encode($voucherUnitsToCombine);
            } else {
                $result = 0;
            }

            return $result;
        }


        for($i = 0; $i < $entryCount; $i++)
        { 

            $clientVoucheramount = DB::table('vouchers')->select('amount')
            ->where([
                ['user_id', $user_id],
                ['used', null]
            ])->get()->pluck('amount');

            $res = [];
            foreach ($clientVoucheramount  as $key => $value) {
                $res[] = $value;
            }

            $customerVoucheramount = DB::table('contacts')->where([['user_id', $user_id],['confirmation', '=', 'Unavailable Vouchers']])->first();
            $voucher = $res;
            $vouchermin = min($voucher);


            if($customerVoucheramount->voucher_amount >= $vouchermin)
            {
                $target = $customerVoucheramount->voucher_amount;
                $result = getNum($voucher, $target);
                $data = json_decode($result);

                if($data != 0){
                    if(is_array($data) == true)
                    {
                        foreach ($data as  $value) 
                        {
                            $Voucher = DB::table('vouchers')->where([['user_id', $user_id],['amount', $value],['used', '=', null]])->first();

                            if(!empty($Voucher))
                            {
                                DB::insert('insert into contact_list (user_id, name, mobile, region, amount, voucher_amount, voucher_code, confirmation, created_at, updated_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [$user_id, $customerVoucheramount->name, $customerVoucheramount->mobile, $customerVoucheramount->region, $Voucher->amount, $customerVoucheramount->voucher_amount, $Voucher->code, 'confirmed', $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);

                                DB::table('vouchers')
                                ->where([
                                    ['user_id', $user_id], 
                                    ['code',$Voucher->code],
                                ])
                                ->update([
                                    'used'=>$customerVoucheramount->mobile,
                                ]);
                            } 
                        } 
                    } else {
                        $Voucher = DB::table('vouchers')->where([['user_id', $user_id],['amount', $data],['used', '=', null]])->first();

                        if(!empty($Voucher))
                        {
                            DB::insert('insert into contact_list (user_id, name, mobile, region, amount, voucher_amount, voucher_code, confirmation, created_at, updated_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [$user_id, $customerVoucheramount->name, $customerVoucheramount->mobile, $customerVoucheramount->region, $Voucher->amount, $customerVoucheramount->voucher_amount, $Voucher->code, 'confirmed', $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);

                            DB::table('vouchers')
                            ->where([
                                ['user_id', $user_id], 
                                ['code',$Voucher->code],
                            ])
                            ->update([
                                'used'=>$customerVoucheramount->mobile,
                            ]);
                        } 
                    }

                    $result = DB::table('contacts')
                    ->where([
                        'user_id' => $user_id, 
                        'id' => $customerVoucheramount->id,
                    ])
                    ->update([
                        'confirmation'=>'Confirmed',
                        'voucher_code'=>1
                    ]); 
                } else {
                    DB::table('contacts')
                    ->where([
                        'user_id' => $user_id, 
                        'id' => $customerVoucheramount->id,
                    ])
                    ->update([
                        'confirmation'=>'Unavailable Vouchers'
                    ]);
                }
                
            } else {
                DB::table('contacts')
                ->where([
                    'user_id' => $user_id, 
                    'id' => $customerVoucheramount->id,
                ])
                ->update([
                    'confirmation'=>'Unavailable Vouchers'
                ]);
            }
        }

        $clustomerCount = DB::table('contact_list')->where([['user_id', $user_id],['msgStatus',null]])->distinct()->count();

        for($i = 0; $i < $clustomerCount; $i++)
        { 
            $user = DB::table('users')->where('id', $user_id)->first();

            $client = DB::table('contact_list')->where('msgStatus', null)->first();

            if($client)
            {
                $customercode = DB::table('contact_list')->select('voucher_code')
                ->where([
                    ['user_id', $user_id],
                    ['mobile', $client->mobile]
                ])->get()->pluck('voucher_code');

                $code = [];
                foreach ($customercode  as $key => $value) {
                    $code[] = $value;
                }

                if(is_array($customercode) == true)
                {
                    
                    $vouchercode = [];
                    foreach ($customercode  as $key => $value) {
                        $vouchercode[] = $value;
                    }
                    $codes = $vouchercode;
                    $json = json_encode($codes);
                    $vouchercode = trim($json, '[]');

                    $msg_data = array(
                    'Client Name' => $client->name.' ',
                    'Client Voucher Code' => $vouchercode.' ' ,
                    'Client Voucher Amount' => $client->voucher_amount.' ' ,
                    'Compaign Name' => $user->compaign_name.' ' ,
                    'Supermarket' => $user->Supermarket.' ' ,
                    'Contacts' => $user->contacts.' ' ,
                    );

                    preg_match_all('~<%(.*?)%>~s', $message, $datas);
                    $Html = $message;
                    foreach ($datas[1] as $value) {
                        if (array_key_exists($value, $msg_data)) {
                            $Html = str_replace($value, $msg_data[$value], $Html);
                        } else {
                            $Html = str_replace($value, '', $Html);
                        }
                    }
                    $result= str_replace(array("<%", "%>"), '', $Html);

                    DB::insert('insert into messages_outgoing (user_id, message, mobile, status, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $result, $client->mobile, 2, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);

                    DB::table('contact_list')
                    ->where([
                        ['user_id', $user_id], 
                        ['mobile',$client->mobile],
                    ])
                    ->update([
                        'msgStatus'=>'Created'
                    ]);
                } else {
                    $json = $customercode;
                    $vouchercode = trim($json, '[]');
                    
                    $msg_data = array(
                    'Client Name' => $client->name.' ',
                    'Client Voucher Code' => $vouchercode.' ' ,
                    'Client Voucher Amount' => $client->voucher_amount.' ' ,
                    'Compaign Name' => $user->compaign_name.' ' ,
                    'Supermarket' => $user->Supermarket.' ' ,
                    'Contacts' => $user->contacts.' ' ,
                    );

                    preg_match_all('~<%(.*?)%>~s', $message, $datas);
                    $Html = $message;
                    foreach ($datas[1] as $value) {
                        if (array_key_exists($value, $msg_data)) {
                            $Html = str_replace($value, $msg_data[$value], $Html);
                        } else {
                            $Html = str_replace($value, '', $Html);
                        }
                    }
                    $result= str_replace(array("<%", "%>"), '', $Html);

                    DB::insert('insert into messages_outgoing (user_id, message, mobile, status, created_at, updated_at) values (?, ?, ?, ?, ?, ?)', [$user_id, $result, $client->mobile, 2, $now->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s')]);

                    DB::table('contact_list')
                    ->where([
                        ['user_id', $user_id], 
                        ['mobile',$client->mobile],
                    ])
                    ->update([
                        'msgStatus'=>'Created'
                    ]);
                }
            }

        }
        

       /* $clientMessage = DB::table('messages_outgoing')->where([['user_id', $user_id], ['status', 2]])->count();


        for($i = 0; $i<$clientMessage; $i++)
        {
            $sendMessage = DB::table('messages_outgoing')->where([['user_id', $user_id], ['status', 2]])->take(1)->first();
            

            $headers = [
                'Cookie: ci_session=ttdhpf95lap45hqt3h255af90npbb3ql'

            ];

            try{
                $encodMessage = rawurlencode($sendMessage->message);
                $url = 'https://gcd.ims.co.ke/expresssms/Api/send_bulk_api?action=send-sms&api_key=Snh2SGFQT0dIZmFtRGU9ZXBlcEQ=&to='.$sendMessage->mobile.'&from='.$user->sender_id.'&sms='.$encodMessage.'&response=json&unicode=0&bulkbalanceuser=voucher';
    
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_ENCODING, "");
                curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                curl_setopt($ch, CURLOPT_TIMEOUT, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true,);
                curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    
                $response = curl_exec($ch);
                $res = json_decode($response);
                
                if($res->code == "ok")
                {
                    DB::table('messages_outgoing')
                    ->where([
                        ['user_id', $user_id], 
                        ['id', $sendMessage->id],
                    ])
                    ->update([
                        'status' => 4,
                    ]);
                }
                curl_close($ch);
            }   catch (\Exception $e) {

                return redirect()->back()->with("error",$e);
            }
        }*/


        return redirect()->back()->with("success","Your voucher codes are being sent to your contacts.");
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Shop;
use Carbon\Carbon;
use Auth;
use App\Imports\CustomerImport;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;

class ShopController extends Controller
{
    public function __construct()
    {
        $this->middleware('role:administrator|superadministrator');
    }


    public function index()
    {
       /*$users = User::whereRoleIs('user')->with(['shop'])->get();*/
        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );
        $user_id = auth()->user()->id;
        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $date= Carbon::today()->toDateString();
        $entryCount = DB::table('contacts')->where('user_id', $user_id)->whereDate('created_at', '=', $date)->count();
        //$entry = DB::table('contacts')->whereDate('created_at', '=', $date)->get();
        $entry = DB::table('contacts')->where('user_id', $user_id)->get();

        $usersCountYesterday = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->whereBetween('registers.created_at', [Carbon::now()->startOfDay(), Carbon::now()])
               ->get();

       $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

        $duplicateRecords = DB::table('contacts')
              ->select('unique_intentifier', DB::raw('count(`unique_intentifier`) as occurences'))
              ->where('user_id', $user_id)
              ->groupBy('unique_intentifier')
              ->having('occurences', '>', 1)
              ->get();


         $duplicateRecordsCount = DB::table('contacts')
              ->select(DB::raw('count(`unique_intentifier`) as occurences'))
              ->where('user_id', $user_id)
              ->groupBy('unique_intentifier')
              ->having('occurences', '>', 1)
              ->first();


       $users= DB::table('shops')->join('users', 'shops.user_id', '=', 'users.id')->get();
       return view('distributors.all')->with(array('users'=>$users, 'usersCount'=>$usersCount, 'dates'=>$dates, 'usersCountYesterday'=>$usersCountYesterday, 'entryCount'=>$entryCount, 'entry'=>$entry, 'duplicateRecords' =>$duplicateRecords, 'duplicateRecordsCount'=>$duplicateRecordsCount));
    }

    public function duplicates()
    {

      $user_id = auth()->user()->id;
      $duplicateRecords = DB::table('contacts')
        ->select('unique_intentifier', DB::raw('count(`unique_intentifier`) as occurences'))
        ->where('user_id', $user_id)
        ->groupBy('unique_intentifier')
        ->having('occurences', '>', 1)
        ->get();

      foreach($duplicateRecords as $record) 
      {
          DB::table('contacts')->where([['unique_intentifier', $record->unique_intentifier], ['user_id', $user_id]])->delete();
      }

      return redirect()->back()->with('success', "Duplicates have been successfully removed.");
    }

    public function shopcreate()
    {
        $day = Carbon::createFromFormat('m', 11)->startOfMonth()->format( 'Y-m-d' );

        $dates = DB::table('registers')->where( 'created_at', '>=', $day)
                     ->groupBy( 'date' )
                     ->orderBy( 'date' )
                     ->get( [
                         DB::raw( 'DATE( created_at ) as date' ),
                         DB::raw( 'COUNT( * ) as "count"' )
                     ] )
                     ->pluck( 'count', 'date' );

        $usersCount = DB::table('shops')
               ->join('registers', 'shops.user_id', '=', 'registers.user_id')
               ->selectRaw('shops.*, count(registers.id) as userCount')
               ->groupBy('shops.id')
               ->get();

       return view('distributors.create')->with(array('usersCount'=>$usersCount, 'dates'=>$dates));
    }

    public function store(Request $request)
    {
        $this->validate($request,
            [
                'sname' => ['required', 'string', 'max:255'],
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'mobile' => ['required', 'numeric', 'unique:users'],
                'location' =>  ['required', 'string', 'max:255'],
                'product' =>  ['required', 'string', 'max:255'],
            ], 
            [
                'sname.required' => 'This is a required field.',
                'sname.max' => 'The character limit is set at 50.',
                'name.required' => 'This is a required field.',
                'name.max' => 'The character limit is set at 140.',
                'email.required' => 'We need to know your e-mail address!',
                'location.required' => 'This is a required field.',
                'product.required' => 'This is a required field.',
            ]
        );

        $password = rand(1000,9999);

        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'mobile' => $request->input('mobile'),
            'password' => Hash::make($password),
            'password_change_at' => 1,
        ]);
        $user->attachRole('user');

        $shop = new Shop;
        $shop->sname = $request->input('sname');
        $shop->location = $request->input('location');
        $shop->product = $request->input('product');
        $shop->user_id = $user->id;
        $shop->save();

        $details = [
                'title' => 'Hi '.$request->input('sname'),
                'body' => 'Welcome to the Twendeni Porini Na Canon Promotion, your credentials include mobile: '.$request->input('mobile').' and password: '.$password.' at http://canon.ims.co.ke/'
            ];

        Mail::to($request->input('email'))->send(new \App\Mail\canonMail($details));

        /*if($user){

            $headers = [
                "Accept: /",
                "Accept-Encoding: gzip, deflate",
                "Cache-Control: no-cache",
                "Connection: keep-alive",
                "Content-Length: 0",
                "Host: 3.229.54.57:8080",
                "Postman-Token: 93db88fd-7432-4cf8-a96f-37dbba8f31b5,434f449e-69da-4341-a0ae-9c261a167ae4",
                "User-Agent: PostmanRuntime/7.19.0",
                "cache-control: no-cache",
                "id: ".$request->input('mobile'),
                "message: Welcome to the Twendeni Porini Na Canon Promotion, your credentials include mobile: ".$request->input('mobile')." and password: ".$password." at http://canon.ims.co.ke/",
                "network: 9",
                "originator: 700801",
                "serviceid: 6013872000123962"
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_PORT, "8080");
            curl_setopt($ch, CURLOPT_URL, "http://3.229.54.57:8080/guinnessutcSMS/sendBulkSMS");
            curl_setopt($ch, CURLOPT_ENCODING, "");
            curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 8);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

            $response = curl_exec($ch);

            curl_close($ch);
        }*/

        return redirect('/shops');
    }

    public function update(Request $request, $id)
    {
        $this->validate($request,
            [
                'sname' => ['string', 'max:255'],
                'name' => ['string', 'max:255'],
                'email' => ['string', 'email', 'max:255'],
                'mobile' => ['numeric'],
                'location' =>  ['string', 'max:255'],
                'product' =>  ['string', 'max:255'],
            ], 
            [
                'sname.max' => 'The character limit is set at 50.',
                'name.max' => 'The character limit is set at 140.',
            ]
        );

        DB::transaction(function () use ($id, $request){

            $user = DB::table('users')
            ->where('id', $id)
            ->update(['name'=>$request->get('name'), 'email'=>$request->get('email'), 'mobile'=>$request->get('mobile')]);

            $currentuser = User::find($id);

            $user_id = $currentuser->id;

            $shop = Shop::where('user_id', $user_id)->first();
            $shop->sname = $request->input('sname');
            $shop->location = $request->input('location');
            $shop->product = $request->input('product');
            
            $shop->save();

        });
        


        return redirect('/shops');
        
    }

    public function import(Request $request)
    {
        try{

            Excel::import(new CustomerImport, $request->file);
            $date= Carbon::today()->toDateString();
            $entryCount = DB::table('registers')->where('created_at', '=',$date)->count();
            return back()->with(array('entryCount'=>$entryCount, 'success'=>'Successfully Imported'));


        }   catch (\Exception $e) {

            return redirect()->back()->with("error","Check Document for Formatting Issues.");
        }
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function multipleusersdelete(Request $request)
    {
        $id = $request->id;
        foreach ($id as $user) 
        {
            User::where('id', $user)->delete();
        }
        return redirect();

    }

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Register;
use Carbon\Carbon;
use Auth;
use App\Voucher;
use App\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;

        $entriesCount= DB::table('contacts')->where('user_id', $user_id)->count();
        $uniqueEntriesCount= DB::table('contacts')->distinct('mobile')->where('user_id', $user_id)->count();
        $completeEntries= DB::table('points')->count();
        $voucherCount = Voucher::where('user_id', $user_id)->get()->count();
        $voucherAvailCount = Voucher::where([['used', null],['user_id', $user_id]])->get()->count();
        $sentMessages = DB::table('messages_outgoing')->where([['user_id', $user_id],['status',4]])->count();
        $failedMessages = DB::table('messages_outgoing')->where([['user_id', $user_id],['status',2]])->count();
                     
        $clientVouchers =  DB::table('vouchers')
              ->select('amount', DB::raw('count(`amount`) as occurences'))
              ->where('user_id', $user_id)
              ->groupBy('amount')
              ->having('occurences', '>', 1)
              ->get();
        

      if ((Auth::user()->password_change_at == null)) {
         return redirect(route('passForm'));
      }
      else{
        return view('home')->with(array('uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'voucherCount'=>$voucherCount, 'voucherAvailCount' => $voucherAvailCount, 'sentMessages'=>$sentMessages, 'clientVouchers'=>$clientVouchers, 'failedMessages'=>$failedMessages));  
      }
    }


}

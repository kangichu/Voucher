<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Register;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Auth;
use App\Voucher;
use App\User;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('role:superadministrator');
    }

    public function index()
    {
        /*$CodeCount= DB::connection('mysql2')->table('codes')->count();*/
        $entriesCount= DB::table('contacts')->count();
        $uniqueEntriesCount= DB::table('contacts')->distinct('mobile')->count();
        $completeEntries= DB::table('points')->count();
        $voucherCount = Voucher::get()->count();
        $voucherAvailCount = Voucher::where('used', null)->get()->count();
        $userCount = User::whereRoleIs('administrator')->count();
        $totalbulk= DB::connection('mysql2')->table('bulkSMSBalance')->select('balance')->where('groupName', 'voucher')->first();
        $sentMessages = DB::table('messages_outgoing')
               ->join('users', 'messages_outgoing.user_id', '=', 'users.id')
               ->selectRaw('users.*, count(messages_outgoing.id) as occurences')
               ->where('status', '=', 4)
               ->groupBy('users.id')
               ->having('occurences', '>', 0)
               ->get();
                     

        $clientVouchers = DB::table('vouchers')
               ->join('users', 'vouchers.user_id', '=', 'users.id')
               ->selectRaw('users.*, count(vouchers.id) as occurences')
               ->groupBy('users.id')
               ->having('occurences', '>', 0)
               ->get();

      if ((Auth::user()->password_change_at == null)) {
         return redirect(route('passForm'));
      }
      else{
        return view('admin.index')->with(array('uniqueEntriesCount'=>$uniqueEntriesCount, 'entriesCount'=>$entriesCount, 'voucherCount'=>$voucherCount, 'userCount'=>$userCount, 'totalbulk' => $totalbulk, 'voucherAvailCount' => $voucherAvailCount, 'sentMessages'=>$sentMessages, 'clientVouchers'=>$clientVouchers)); 
      }

       
    }
}
